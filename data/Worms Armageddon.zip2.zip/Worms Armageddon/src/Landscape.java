import javax.swing.*;

public class Landscape extends JPanel {
    int windowHeight;
    int windowWidth;
    public static final int width = 800;
    public static final int heigh = 400;
    Boolean[][] bool;
    int randomX;
    int randomY;
    int randomR;
    double distance;

    public Landscape(int windowWidth, int windowHeight) {
        this.windowHeight = windowHeight;
        this.windowWidth = windowWidth;
        bool = new Boolean[windowWidth][windowWidth];
        for (int i = 0; i < windowWidth; i++) {
            for (int j = 0; j < windowHeight; j++) {
                bool[i][j] = false;
            }
        }
        for (int i = 100; i < width+100; i++) {
            for (int j = windowHeight; j > windowHeight - heigh; j = j - 1) {
                bool[i][j] = true;
            }
        }
        randomX = (int)(Math.random()*windowWidth);
        randomY = (int)(Math.random()*windowHeight);
        randomR = (int)(Math.random()*60);
        for (int i = randomX-randomR;i<randomX+randomR; i++ ){
            for (int j = randomY-randomR;j<randomY+randomR; i++ ){
                distance=Math.sqrt(Math.pow((randomX-i),2)+Math.pow((randomY-j),2));
                if((distance<randomR)&&(bool[i][j])){
                    bool[i][j] = false;
                }
            }
        }
    }
}
