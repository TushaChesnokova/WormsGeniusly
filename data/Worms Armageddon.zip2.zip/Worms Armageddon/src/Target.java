import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Target {
    int x;
    int y;
    double sin;
    public static final int width = 30;
    void Target() {

    }
}
