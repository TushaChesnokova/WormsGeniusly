import javax.swing.*;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws InterruptedException, IOException {
        JFrame frame = new JFrame();
        frame.setSize(1000, 700);
        int windowWidth = frame.getWidth();
        int windowHeight = frame.getHeight();
        World world = new World(windowWidth, windowHeight);
        frame.add(world);
        frame.setUndecorated(true);
        frame.addMouseListener(world.c);
        frame.addMouseMotionListener(world.c);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        while (true) {
            world.c.dt++;
            world.c.update();
            Thread.sleep(1000 / 30);
            frame.repaint();
        }
    }
}
