import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.HashMap;

public class Controller implements MouseListener, MouseMotionListener {
    HashMap<Integer, Boolean> keys = new HashMap<>();
    KeyboardFocusManager keyboard;
    World world;
    boolean up = false;
    int k = -1;
    double v = 0;
    int dt = 0;
    double g;
    int clickCounter = 0;

    Controller(World world) {
        this.world = world;
        keyboard = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        keyboard.addKeyEventDispatcher(new KeyEventDispatcher() {
            @Override
            public boolean dispatchKeyEvent(KeyEvent e) {
                if (e.getID() == KeyEvent.KEY_PRESSED) {
                    if ((world.controllerWorm.health != 0) && (e.getKeyCode() == KeyEvent.VK_UP) && (v == 0)) {
                        v = -0.3;
                        dt = 0;
                        g = 0.001;
                        up = true;
                    }
                    if (e.getKeyCode() == KeyEvent.VK_LEFT) {

                    }
                    if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

                    }
                    keys.put(e.getKeyCode(), true);
                }
                if (e.getID() == KeyEvent.KEY_RELEASED) {
                    keys.put(e.getKeyCode(), false);
                }
                return false;
            }
        });
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        //System.out.println(e.getX() + "," + e.getY());
        for (int i = 0; i < world.n; i++) {
            //System.out.println(world.worms[i].x+","+world.worms[i].y+"w");
            if ((e.getX() >= world.worms[i].x) && (e.getX() <= world.worms[i].x + world.worms[i].width) && (e.getY() >= world.worms[i].y) && (e.getY() <= world.worms[i].y + world.worms[i].height)) {
                world.controllerWorm = world.worms[i];
                k = i;
                v = 0;
                //dt = 0;
                //g = 0;
            }
        }
        if ((e.getX() >= world.weaponX - 750) && (e.getX() <= world.weaponX - 750 + world.weaponWidth) && (e.getY() >= world.weaponY) && (e.getY() <= world.weaponY + world.weaponWidth)) {
            world.weapon = true;
        }
        if ((world.weapon) && (e.getX() >= world.weaponX + 5) && (e.getX() <= world.weaponX + world.weaponWidth) && (e.getY() >= world.weaponY) && (e.getY() <= world.weaponY + world.weaponHeight)) {
            world.bombB = true;
            world.weapon = false;
        }
        if (world.bombB) {
            clickCounter++;
            if (clickCounter == 2) {
                world.bomb.x = e.getX();
                world.bomb.y = e.getY();
                world.bombB = false;
                world.bomb.realised = true;
                clickCounter = 0;
                g = 0.001;
                world.target.sin = (world.bomb.y + world.target.width / 2 - world.controllerWorm.y) / (Math.sqrt(Math.pow((world.bomb.x + world.target.width / 2 - world.controllerWorm.x + world.bomb.width / 2), 2) - Math.pow((world.bomb.y + world.target.width - world.controllerWorm.y), 2)));
                world.bomb.x = world.controllerWorm.x - world.bomb.width / 2;
                System.out.println(world.target.sin);
                world.bomb.y = world.controllerWorm.y;
                dt = 0;
                world.bomb.vy = world.bomb.v * world.target.sin;
                world.bomb.vx = world.bomb.v * Math.sqrt(1 - Math.pow(world.target.sin, 2));
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public void update() {
        world.controllerWorm.y = (int) (world.controllerWorm.y + v * dt);
        v = v + g * dt;
        for (int i = 0; i < world.n; i++) {
            if ((world.worms[i].health != 0) && !(world.landscape.bool[world.worms[i].x][(int) (world.worms[i].y + v * dt) + world.worms[i].height]) && (k != -1) && (!up)) {
                world.worms[i].y = (int) (world.worms[i].y + v * dt);
                v = v + g * dt;
                v = 2;
                dt = 0;
                g = 0.001;
            }
        }
        if ((world.controllerWorm.health != 0) && (world.landscape.bool[world.controllerWorm.x][(int) (world.controllerWorm.y + v * dt) + world.controllerWorm.height - 3])) {
            v = 0;
            //dt = 0;
            g = 0;
        }
        if (keys.containsKey(KeyEvent.VK_RIGHT)) {
            if (keys.get(KeyEvent.VK_RIGHT)) {
                if ((world.controllerWorm.health != 0) && !(world.landscape.bool[world.controllerWorm.x + 1][world.controllerWorm.y + world.controllerWorm.height - 3])) {
                    world.controllerWorm.x = world.controllerWorm.x + 1;
                }
            }
        }
        if (keys.containsKey(KeyEvent.VK_LEFT)) {
            if (keys.get(KeyEvent.VK_LEFT)) {
                if ((world.controllerWorm.health != 0) && !(world.landscape.bool[world.controllerWorm.x - 1][world.controllerWorm.y + world.controllerWorm.height - 3])) {
                    world.controllerWorm.x = world.controllerWorm.x - 1;
                }
            }
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {//зажимаю
    }

    @Override
    public void mouseMoved(MouseEvent e) {//двигаю
        if (world.bombB) {
            world.target.x = e.getX();
            world.target.y = e.getY();
        }
    }
}
