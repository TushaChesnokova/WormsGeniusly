import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class World extends JPanel {
    int n = 2;
    boolean weapon = false;
    Target target = new Target();
    Bomb bomb = new Bomb();
    boolean bombB = false;
    int weaponX = 820;
    int weaponY = 30;
    int weaponWidth = 40;
    int weaponHeight = 50;
    Worm controllerWorm = new Worm(0, 0);
    Worm[] worms = new Worm[n];
    BufferedImage landscapeImage;
    Landscape landscape;
    BufferedImage wormGirlImage;
    BufferedImage wormBoyImage;
    BufferedImage bombImage;
    BufferedImage weaponImage;
    BufferedImage boardImage;
    BufferedImage targetImage;
    BufferedImage backgroundImage;
    int windowHeight;
    int windowWidth;
    double distance;
    Controller c = new Controller(this);

    public World(int windowWidth, int windowHeight) throws IOException {
        this.landscapeImage = ImageIO.read(new File("Ландшафт.jpg"));
        this.wormGirlImage = ImageIO.read(new File("Girl.png"));
        this.wormBoyImage = ImageIO.read(new File("Boy.png"));
        this.bombImage = ImageIO.read(new File("бомба.png"));
        this.boardImage = ImageIO.read(new File("доска.png"));
        this.backgroundImage = ImageIO.read(new File("фон.jpg"));
        this.weaponImage = ImageIO.read(new File("оружие.jpg"));
        this.targetImage = ImageIO.read(new File("мишень.png"));
        this.windowWidth = windowWidth;
        this.windowHeight = windowHeight;
        for (int i = 0; i < n; i++) {
            worms[i] = new Worm((int) (Math.random() * (landscape.width - worms[i].height) + 100), windowHeight - landscape.heigh - worms[i].height + 3);
        }
        landscape = new Landscape(windowWidth, windowHeight);
    }

    @Override
    protected void paintComponent(Graphics g) {
        g.drawImage(backgroundImage, 0, 0, windowWidth, windowHeight, null);
        if (controllerWorm.y >= windowHeight - controllerWorm.height - 3) {
            controllerWorm.health = 0;
        }
        g.drawImage(weaponImage, weaponX - 750, weaponY, weaponWidth, weaponWidth, null);
        for (int i = 0; i < windowWidth; i += 3) {
            for (int j = 0; j < windowHeight; j = j + 3) {
                if (landscape.bool[i][j]) {
                    g.drawImage(landscapeImage, i, j, 3, 3, null);
                }
            }
        }
        for (int i = 0; i < n; i++) {
            if ((i % 2 == 0) && (worms[i].health != 0)) {
                g.drawImage(wormBoyImage, worms[i].x, worms[i].y, worms[i].width, worms[i].height, null);
                worms[i].team = Team.BOY;
            }
            if ((i % 2 != 0) && (worms[i].health != 0)) {
                g.drawImage(wormGirlImage, worms[i].x, worms[i].y, worms[i].width, worms[i].height, null);
                worms[i].team = Team.GIRL;
            }
            if (worms[i].health != 0) {
                g.drawString(Integer.toString(worms[i].health), worms[i].x + worms[i].width - 15, worms[i].y);
            }
        }
        if (weapon) {
            g.drawImage(boardImage, weaponX, weaponY, 130, 200, null);
            g.drawImage(bombImage, weaponX + 5, weaponY, weaponWidth, weaponHeight, null);
        }
        if (bombB) {
            g.drawImage(targetImage, target.x, target.y, target.width, target.width, null);
            g.drawImage(bombImage, controllerWorm.x - bomb.width, controllerWorm.y, bomb.width, bomb.width, null);
        }
        if (bomb.realised) {
            //System.out.println(bomb.x+","+bomb.y+","+bomb.vx+","+bomb.vy+","+c.dt+","+c.g);
            bomb.x = (int)(bomb.x+ bomb.vx*c.dt);
            bomb.y = (int)(bomb.y+ bomb.vy*c.dt);
            bomb.vy = bomb.vy+c.g;
            g.drawImage(bombImage, bomb.x, bomb.y, bomb.width, bomb.width, null);
            if (landscape.bool[bomb.x][bomb.y]){
               // System.out.println("2");
                bomb.realised = false;
                bomb.explosion = true;
            }
            c.dt=0;
        }
        if(bomb.explosion){
            for(int i=0; i<n; n++){
               distance = Math.sqrt(Math.pow((bomb.x-worms[i].x),2)+Math.pow((bomb.y-worms[i].y),2));
               if (distance<bomb.radius){
                   worms[i].health =  (int)(worms[i].health-bomb.health*(bomb.radius-distance)/bomb.radius);
               }
            }
            for(int i=0; i<windowWidth; i++){
                for(int j=0; j<windowHeight;j++){
                    distance=Math.sqrt(Math.pow((bomb.x-i),2)+Math.pow((bomb.y-j),2));
                    if((distance<bomb.radius)&&(landscape.bool[i][j])){
                        landscape.bool[i][j] = false;
                    }
                }
            }
            bomb.explosion = false;
        }
    }
}
