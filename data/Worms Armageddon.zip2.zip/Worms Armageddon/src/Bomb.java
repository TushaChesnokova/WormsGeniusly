public class Bomb {
    public static final int health = 40;
    boolean realised = false;
    public static final int width = 20;
    public static final int radius = 50;
    int x;
    int y;
    public static final double v = 0.05;
    double vx;
    double vy;
    boolean explosion = false;
}
