public enum Team {
    GIRL,
    BOY
}
