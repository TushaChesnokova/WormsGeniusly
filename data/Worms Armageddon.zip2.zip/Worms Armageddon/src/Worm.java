public class Worm {
    Team team;
    int health = 125;
    public static final int width = 40;
    public static final int height = 35;

    public Worm(int x, int y) {
        this.x = x;
        this.y = y;
    }

    int x;
    double v;
    int y;

}
